# Apex Project

A CLI tool for creating and managing projects.

## Installation

You can install the package via pip:

```bash
pip install apex_project
